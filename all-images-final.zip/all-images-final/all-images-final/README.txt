THE UNLIMITED INDIAN AIR FRYER COOKBOOK - ALL IMAGES (Instagram icon added before @popin_shopin)

01-covers-1270x780/       every cover, exactly 1270 x 780 px (JPG + PNG)
02-thumbnails-600x600/    every thumbnail, exactly 600 x 600 px (JPG + PNG)
03-more-sizes/            same designs in other sizes (JPG): square 1080x1080, widescreen 1920x1080,
                          Instagram 4:5 1080x1350 and book cover 1080x1527 (A-D only)
04-3d-mockups/            3D book mockups, 2000x1500 JPG (clean background) + transparent PNG,
                          and a lineup of the four new designs

Designs: A-noir-champagne, B-ivory-editorial, C-midnight-saffron, D-terracotta-cream,
         E-yellow-bold, F-royal-maroon / F-royal-emerald / F-royal-navy
Use the same letter for the cover and thumbnail on your listing (A with A, etc).

This folder replaces the older folders (cover-designs, topmate, royal, ebook-mockups, topmate-final).
Photos are reference photos - replace before selling. Titles say "UNLIMITED"; the PDF says "Ultimate".
